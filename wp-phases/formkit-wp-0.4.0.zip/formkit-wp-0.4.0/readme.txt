FormKit WP 0.4.0 – Modular (Core/Contracts/Renderers), DOI, Admin-UI, PDF (Dompdf).
Shortcodes: [formkit slug="contact"], [formkit slug="reservation"]
REST: GET /wp-json/formkit/v1/preview?slug=contact, GET /wp-json/formkit/v1/pdf?slug=menu

PDF: Bitte lokal im Plugin-Verzeichnis ausführen und vendor/ hochladen:
composer require dompdf/dompdf:^2.0
